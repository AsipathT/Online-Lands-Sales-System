<?php
include 'connect.php';


// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Gather user input from the form
    $title = $_POST['title'];
    $name = $_POST['name'];
    $email = $_POST['email'];
    $mobile = $_POST['mobile'];
    $subject = $_POST['subject'];
    $message = $_POST['message'];

   
   

    // SQL to insert user data into the database
    $sql = "INSERT INTO  crud (title, name, email, mobile, subject, message) 
            VALUES ('$title', '$name', '$email', '$mobile', '$subject', '$message')";

    // Execute SQL query
    if (mysqli_query($con, $sql)) {
        echo "<script>alert('Registration successful');</script>"; 
        exit();
    } else {
        echo "Error: " . $sql . "<br>";
    }
  } 

// Close database connection
mysqli_close($con);
?>



<!DOCTYPE html>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">

<link rel="stylesheet" href="styles\styles.css">


</head>

<body>
	
    <script src="script.js"></script>
	

	<!-- horizontal navigation bar -->
	
	
	<main>
	    <section id="formC">
            <h2> Contact Us </h2>		
			<form action="display.php" method="POST">
			<div class="form-group">
			    <input type="text" name="title" placeholder="Title-" required> <br><br>
			    <input type="text" name="name" placeholder="Name-" required> <br><br>
				<input type="email" name="email" placeholder="Email-" required> <br><br>
				<input type="text" name="mobile" placeholder="Phone No-"required> <br><br>
				<input type="text" name="subject" placeholder="Subject-"required> <br><br>

			</div>
			
		</section>
	</main>
	
	<div class="n2">
        <fieldset>
			<legend>Message:</legend>
			<textarea name="message" id="Message" placeholder="Message" required rows="8" cols="40"></textarea>
		</fieldset>
	</div>
	<section class="Sbutton">
		<div class="form-group">
			
		
			<input type="submit" value="Submit" id="submit">
			


		</div>
	</section>
</form>
<script>
    document.getElementById("submit").addEventListener("click", function() {
        alert("Registration Successful");
        window.location.href = "display.php"; // Redirect to display.php
    });
</script>



</body>




	
	<!-- footer begins -->
	

		
	
	
	
	
	

